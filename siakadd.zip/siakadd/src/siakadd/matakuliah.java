/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siakadd;

/**
 *
 * @author TobiSan
 */
public class matakuliah {
    public String kode,nmk;
     public int sks, sem;
     
     public matakuliah(String kode , String nmk, int sks, int sem ){
                this.kode = kode;
                this.nmk = nmk;
                this.sks = sks;
                this.sem = sem;
     }
     public matakuliah(){
     
     }
    
}
